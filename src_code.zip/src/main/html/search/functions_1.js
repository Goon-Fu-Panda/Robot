var searchData=
[
  ['lijnsensor_0',['lijnSensor',['../classlijn_sensor.html#a3d9ef979219fdc517e6071ead64bd518',1,'lijnSensor::lijnSensor()'],['../classlijn_sensor.html#a5d0869a53365ead38e82a6390433cf5f',1,'lijnSensor::lijnSensor(unsigned char *, unsigned char, unsigned int, unsigned char)']]]
];
