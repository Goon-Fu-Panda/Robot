var indexSectionsWithContent =
{
  0: "alpx~",
  1: "lx",
  2: "alpx~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

