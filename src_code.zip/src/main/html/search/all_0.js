var searchData=
[
  ['aanwezigheidlijn_0',['aanwezigheidLijn',['../classlijn_sensor.html#a73c709c81bf1ddc7e5474a8122e9d4b5',1,'lijnSensor']]],
  ['afwijkinglijn_1',['afwijkingLijn',['../classlijn_sensor.html#a7659da3e55a4ace103047d32b6fa40ca',1,'lijnSensor']]]
];
